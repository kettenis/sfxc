//
// C++ include file wrapper around VEX library
//
#ifndef _VEXX_H_
#define _VEXX_H_

extern "C" {
#include "vex.h"
#include "y.tab.h"
}

#endif
